﻿// TestApplication1.cpp : 此文件包含 "main" 函数。程序执行将在此处开始并结束。
//

#include <iostream>
#include <windows.h>

int main()
{
    DWORD64 addr =  (DWORD64)VirtualAllocEx(GetCurrentProcess(), 0, 0x1000, MEM_COMMIT, PAGE_READWRITE);
    std::cout << addr<<"\n";
    while (1)
    {
        std::cout << "Hello World!\n";
        Sleep(1000);
    }
    
}
