#pragma once
#include <stdio.h>
#include <windows.h>

#define CODE_SIZE 0x100 //�����볤��

typedef enum emRefgister64
{
	HEAD = 14,
	RAX,
	RCX,
	RDX,
	RBX,
	RSP,
	RBP,
	RSI,
	RDI,
	R8,
	R9,
	R10,
	R11,
	R12,
	R13,
	R14,
	R15,
	RIP
}EMRG64;

typedef struct stGadgetInfo
{
	EMRG64 SrcRegister;
	EMRG64 DstRegister;
	DWORD RegisterOffset;
	DWORD dwPreStackSize;
	DWORD64 qwGadgetAddress;
	DWORD64 qwAutoLockAddress;
}GGIF, *PGGIF;

PVOID GwGetGadgetInfo(IN PCHAR ModuleName, IN PCHAR FuncName, IN DWORD dwSearchLen, IN PBYTE argSignature);
BOOL GwSuspendThread(IN DWORD dwThreadId, OUT LPHANDLE lpThreadHandle, OUT LPCONTEXT lpContext);
BOOL GwResumeThread(IN LPHANDLE lpThreadHandle, IN LPCONTEXT lpContext);
VOID GwWriteReturnAddress(IN LPHANDLE lpThreadHandle, IN PGGIF pGadgetInfo);